import json
import os

INPUT_FILE = "accounts.json"
OUTPUT_FILE = "account(activate).json"

# Main accounts file read
with open(INPUT_FILE, "r", encoding="utf-8") as f:
    data = json.load(f)

# Sirf activated accounts
new_data = []

for x in data:
    if x.get("activated") is True:
        new_data.append({
            "uid": x.get("uid"),
            "password": x.get("password"),
            "account_id": x.get("account_id"),
            "activated": True,
            "nickname": x.get("nickname")
        })

# Agar output file pahle se hai, uska purana data rakho
if os.path.exists(OUTPUT_FILE):
    with open(OUTPUT_FILE, "r", encoding="utf-8") as f:
        try:
            old_data = json.load(f)
            if not isinstance(old_data, list):
                old_data = []
        except json.JSONDecodeError:
            old_data = []
else:
    old_data = []

# Purane + naye accounts
old_data.extend(new_data)

# Save without deleting old data
with open(OUTPUT_FILE, "w", encoding="utf-8") as f:
    json.dump(old_data, f, indent=2, ensure_ascii=False)

print(f"Done — {len(new_data)} new activated accounts added.")
print(f"Total accounts in file: {len(old_data)}")