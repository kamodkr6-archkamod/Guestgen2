#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os, sys, json, time, random, string, hashlib, threading, base64, codecs, re, uuid, hmac, ipaddress, zlib, binascii
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor, as_completed
from Crypto.Cipher import AES
from Crypto.Util.Padding import pad, unpad
import requests
import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# ============================================================
#  COLOR CODES
# ============================================================
GREEN = "\033[92m"
YELLOW = "\033[93m"
BLUE = "\033[94m"
CYAN = "\033[96m"
RED = "\033[91m"
PURPLE = "\033[95m"
WHITE = "\033[97m"
BOLD = "\033[1m"
RESET = "\033[0m"

# ============================================================
#  BANNER
# ============================================================
def print_banner():
    os.system('cls' if os.name == 'nt' else 'clear')
    print(f"""
{BOLD}{PURPLE}
░█████╗░░█╗░░█╗░█╗
██╔══██╗██╔══██╗██╔══██╗██╔══════░░█░█
═█╔══██╔══██║██╔══█║░
██║█║░██░██║░░░
╚═╝░░╚═╝╚═╝░╚═╝╚═╝░
{RESET}
{BOLD}{YELLOW}   🔥 GUEST {RESET} {GREEN}. {RESET}
{RED} GUEST ACCOUNT 
{GREEN} .
{BOLD}{CYAN}             . .{RESET}
{BOLD}{GREEN}   ✅ Batch Mode: Register(N) → Activate(N) → Spin(N) → Repeat{RESET}
{BOLD}{GREEN}   ✅ Only ACTIVATED accounts saved (no JWT){RESET}
{BOLD}{GREEN}   ✅ Rare items (RARE + VERY_RARE) auto saved to special json{RESET}
""")

# ============================================================
#  MODERN TERMINAL UI
# ============================================================
def ui_line(char="━", width=62, color=BLUE):
    print(f"{color}{char * width}{RESET}")

def ui_header(title, subtitle=None):
    ui_line()
    print(f"{BOLD}{CYAN}  {title.center(58)}{RESET}")
    if subtitle:
        print(f"{WHITE}  {subtitle.center(58)}{RESET}")
    ui_line()

def ui_status(label, value, color=WHITE):
    print(f"{BOLD}{CYAN}  {label:<18}{RESET} {color}{value}{RESET}")

def ui_step(number, title, detail=""):
    print(f"{BOLD}{PURPLE}  [{number}] {title}{RESET}", end="")
    if detail:
        print(f" {WHITE}→ {detail}{RESET}")
    else:
        print()

# ============================================================
#  SETTINGS
# ============================================================
CLIENT_VERSION = "1.132.1"
OB_VERSION = "OB55"

# ============================================================
#  CRYPTO KEYS
# ============================================================
AES_KEY = bytes([89,103,38,116,99,37,68,69,117,104,54,37,90,99,94,56])
AES_IV  = bytes([54,111,121,90,68,114,50,50,69,51,121,99,104,106,77,37])
CLIENT_SECRET = "2ee44819e9b4598845141067b281621874d0d5d7af9d8f7e00c1e54715b7d1e3"
NICK_XOR_KEY = b'1e5898ccb8dfdd921f9bdea848768b64a201'

REGION_LANG = {
    "IND":"hi", "BR":"pt", "US":"en", "ID":"id", "TH":"th",
    "VN":"vi", "ME":"ar", "SG":"ms", "PK":"ur", "BD":"bn",
    "EUROPE":"fr", "RU":"ru", "NA":"na", "SAC":"es", "TW":"zh"
}
SUPPORTED_REGIONS = {
    "1": "IND", "2": "BR", "3": "US", "4": "ID", "5": "TH",
    "6": "VN", "7": "ME", "8": "SG", "9": "PK", "10": "BD",
    "11": "EUROPE", "12": "RU", "13": "NA", "14": "SAC", "15": "TW"
}
REGION_BASE_URLS = {
    "IND": "https://client.ind.freefiremobile.com",
    "BR":  "https://client.br.freefiremobile.com",
    "US":  "https://client.na.freefiremobile.com",
    "ID":  "https://client.id.freefiremobile.com",
    "TH":  "https://client.th.freefiremobile.com",
    "VN":  "https://client.vn.freefiremobile.com",
    "ME":  "https://client.me.freefiremobile.com",
    "SG":  "https://client.sg.freefiremobile.com",
    "PK":  "https://client.pk.freefiremobile.com",
    "BD":  "https://client.bd.freefiremobile.com",
    "EUROPE": "https://client.eu.freefiremobile.com",
    "RU":  "https://client.ru.freefiremobile.com",
    "NA":  "https://client.na.freefiremobile.com",
    "SAC": "https://client.sac.freefiremobile.com",
    "TW":  "https://client.tw.freefiremobile.com",
}

# ============================================================
#  SPIN CONFIG
# ============================================================
SPIN_URL = "https://client.ind.freefiremobile.com/PurchaseGacha"
SPIN_BODY_HEX = "d120b9daac2c87872b8c115dfd74a832"

# ============================================================
#  ITEM DATABASE
# ============================================================
ITEM_DB = {
    710047022: ("NARUTO BUNDLE",         "VERY_RARE"),
    909047015: ("RASENGAN EMOTE",        "RARE"),
    907104746: ("HOKAGE ROCK GLOW WALL", "RARE"),
    904047008: ("HOKAGE GLOW WALL",      "NORMAL"),
    903047008: ("RASENGAN SKIN",         "NORMAL"),
}

def classify_item(item_id: int):
    if item_id in ITEM_DB:
        return ITEM_DB[item_id]
    return (f"UNKNOWN_{item_id}", "NORMAL")

# ============================================================
#  IP ROTATOR
# ============================================================
class IPRotator:
    REGION_IP_CIDRS = {
        "BD": ["27.147.128.0/17","37.111.192.0/19","49.0.32.0/20","59.152.96.0/20","114.130.0.0/17","115.127.0.0/17","119.30.32.0/20","123.49.0.0/18","103.220.220.0/22","103.108.140.0/22","103.242.20.0/22"],
        "IND": ["1.6.0.0/15","1.38.0.0/15","14.96.0.0/15","27.4.0.0/14","27.56.0.0/13"],
        "ID": ["36.64.0.0/11","101.255.0.0/16","103.10.60.0/22","114.120.0.0/13"],
        "TH": ["1.46.0.0/15","27.55.0.0/16","49.228.0.0/15","101.108.0.0/15"],
        "VN": ["1.52.0.0/14","14.160.0.0/11","27.64.0.0/12","113.160.0.0/12"],
        "PK": ["39.32.0.0/11","111.68.96.0/19","182.176.0.0/12"],
        "ME": ["2.88.0.0/13","5.100.0.0/14","31.166.0.0/15","37.104.0.0/13"],
        "BR": ["177.0.0.0/13","186.192.0.0/12","189.0.0.0/11","200.96.0.0/12"],
        "EU": ["2.16.0.0/12","5.144.0.0/14","31.40.0.0/14","46.16.0.0/14"],
        "CIS": ["2.92.0.0/14","5.136.0.0/13","31.128.0.0/12","46.0.0.0/12"],
        "NA": ["3.0.0.0/9","8.0.0.0/12","12.0.0.0/10","24.0.0.0/10"],
        "SAC": ["186.0.0.0/10","190.0.0.0/11","200.0.0.0/11"],
        "TW": ["1.160.0.0/12","36.224.0.0/12","114.24.0.0/12","118.160.0.0/12"]
    }
    _cache = {}
    _cache_lock = threading.Lock()

    @classmethod
    def get_random_ip(cls, region):
        region = region.upper()
        with cls._cache_lock:
            if region not in cls._cache:
                cidrs = cls.REGION_IP_CIDRS.get(region)
                if not cidrs:
                    ip = f"{random.randint(1,255)}.{random.randint(0,255)}.{random.randint(0,255)}.{random.randint(0,255)}"
                    cls._cache[region] = [ip]
                else:
                    hosts = []
                    for cidr in cidrs:
                        try:
                            net = ipaddress.ip_network(cidr, strict=False)
                            # sample small range to avoid memory blow
                            total_hosts = 2 ** (32 - net.prefixlen)
                            if total_hosts > 5000:
                                for _ in range(2000):
                                    hosts.append(str(net.network_address + random.randint(1, total_hosts - 2)))
                            else:
                                hosts.extend([str(ip) for ip in net.hosts()])
                        except Exception:
                            continue
                    if not hosts:
                        net = ipaddress.ip_network(cidrs[0], strict=False)
                        hosts = [str(net.network_address + random.randint(1, 2**(32-net.prefixlen)-2))]
                    cls._cache[region] = hosts
            return random.choice(cls._cache[region])

# ============================================================
#  RANDOM HELPERS
# ============================================================
def generate_random_user_id():
    return f"Google|{uuid.uuid4()}"

DEVICES = [
    "ASUS_AI2401_A", "SM-G998B", "CPH2095", "Pixel 6", "OnePlus 9 Pro",
    "Samsung Galaxy S23 Ultra", "iPhone 14 Pro Max", "Xiaomi 13 Pro",
    "Redmi Note 10 Pro", "Moto G100", "OPPO Find X3", "Vivo X60 Pro",
    "Realme GT 5G", "Nokia 8.3", "OnePlus Nord 2", "Pixel 5a",
    "Samsung A52", "Xiaomi Mi 11", "Poco X3", "LG Velvet"
]

def random_user_agent_msdk():
    device = random.choice(DEVICES)
    version = random.choice(["9", "10", "11", "12", "13"])
    lang = random.choice(["en", "hi", "id", "th"])
    region = random.choice(["US", "IND", "ID", "TH"])
    return f"GarenaMSDK/4.0.42({device} ;Android {version};{lang};{region};app 2.127.1 2019118047;)"

def random_user_agent_unity():
    return "UnityPlayer/2022.3.47f1 (UnityWebRequest/1.0, libcurl/8.5.0-DEV)"

def random_nickname(prefix):
    adjectives = ["Cool", "Happy", "Fast", "Smart", "Brave", "Lucky", "Mighty", "Shadow", "Blaze", "Phoenix"]
    nouns = ["Tiger", "Eagle", "Wolf", "Dragon", "Falcon", "Viper", "Cobra", "Ninja", "Knight", "Ghost"]
    nickname = prefix + random.choice(adjectives) + random.choice(nouns) + ''.join(random.choices(string.digits, k=4))
    return nickname[:15]

def random_password(base):
    chars = string.ascii_letters + string.digits
    suffix = ''.join(random.choices(chars, k=6))
    return f"{base}_{suffix}"

# ============================================================
#  HASH + SIGNATURE
# ============================================================
def hash_password(password):
    return hashlib.sha256(password.encode('utf-8')).hexdigest()

def register_guest(session, password, client_ip=None):
    url = "https://100067.connect.garena.com/api/v2/oauth/guest:register"
    hashed_pw = hash_password(password)
    payload = {"app_id": 100067, "client_type": 2, "password": hashed_pw, "source": 2}
    body_str = json.dumps(payload, separators=(',', ':'), sort_keys=True)
    signature = hmac.new(CLIENT_SECRET.encode('utf-8'), body_str.encode('utf-8'), hashlib.sha256).hexdigest()
    headers = {
        "User-Agent": random_user_agent_msdk(),
        "Authorization": f"Signature {signature}",
        "Accept": "application/json",
        "Content-Type": "application/json; charset=utf-8",
        "Accept-Encoding": "gzip",
        "Connection": "Keep-Alive"
    }
    if client_ip:
        headers['X-Forwarded-For'] = client_ip
        headers['X-Real-IP'] = client_ip
    resp = session.post(url, data=body_str, headers=headers, timeout=15)
    if resp.status_code != 200:
        resp.raise_for_status()
    data = resp.json()
    if data.get("code") != 0:
        raise Exception(f"Register failed: {data}")
    return str(data["data"]["uid"])

# ============================================================
#  PROTOBUF HELPERS
# ============================================================
def varint_encode(n):
    out = []
    while True:
        b = n & 0x7F
        n >>= 7
        if n:
            b |= 0x80
        out.append(b)
        if not n:
            break
    return bytes(out)

def build_field(field_num, value):
    if isinstance(value, bool):
        return varint_encode((field_num << 3) | 0) + varint_encode(1 if value else 0)
    elif isinstance(value, int):
        return varint_encode((field_num << 3) | 0) + varint_encode(value)
    elif isinstance(value, (str, bytes)):
        data = value.encode('utf-8') if isinstance(value, str) else value
        return varint_encode((field_num << 3) | 2) + varint_encode(len(data)) + data
    elif isinstance(value, dict):
        sub = assemble_proto(value)
        return varint_encode((field_num << 3) | 2) + varint_encode(len(sub)) + sub
    else:
        raise TypeError(f"Unsupported type for field {field_num}: {type(value)}")

def assemble_proto(fields):
    packet = b''
    for k in sorted(fields.keys(), key=lambda x: int(x)):
        v = fields[k]
        idx = int(k)
        if isinstance(v, list):
            for item in v:
                packet += build_field(idx, item)
        else:
            packet += build_field(idx, v)
    return packet

def aes_encrypt(plain):
    cipher = AES.new(AES_KEY, AES.MODE_CBC, AES_IV)
    return cipher.encrypt(pad(plain, AES.block_size))

def aes_decrypt(d):
    if len(d) % 16 != 0:
        return d
    raw = AES.new(AES_KEY, AES.MODE_CBC, AES_IV).decrypt(d)
    try:
        return unpad(raw, AES.block_size)
    except ValueError:
        return raw

def parse_proto(data):
    from google.protobuf.internal.decoder import _DecodeVarint, _DecodeVarint32
    pos, length = 0, len(data)
    result = {}
    while pos < length:
        key, pos = _DecodeVarint(data, pos)
        field = key >> 3
        wire = key & 7
        if wire == 0:
            val, pos = _DecodeVarint(data, pos)
        elif wire == 2:
            size, pos = _DecodeVarint32(data, pos)
            raw = data[pos:pos+size]
            pos += size
            try:
                val = parse_proto(raw)
            except:
                try:
                    val = raw.decode('utf-8')
                except:
                    val = raw.hex()
        elif wire == 5:
            val = int.from_bytes(data[pos:pos+4], 'little')
            pos += 4
        elif wire == 1:
            val = int.from_bytes(data[pos:pos+8], 'little')
            pos += 8
        else:
            raise Exception(f"Unsupported wire type {wire}")
        if field in result:
            if not isinstance(result[field], list):
                result[field] = [result[field]]
            result[field].append(val)
        else:
            result[field] = val
    return result

def _read_varint(data, pos):
    result = 0; shift = 0
    while pos < len(data):
        bv = data[pos]; pos += 1
        result |= (bv & 0x7F) << shift
        if not (bv & 0x80): break
        shift += 7
    return result, pos

def _try_parse_proto(raw: bytes):
    if not raw: return None
    out = {}; pos = 0; seen = 0
    try:
        while pos < len(raw):
            tag, pos = _read_varint(raw, pos)
            if tag == 0: return None
            fn, wt = tag >> 3, tag & 7
            if fn == 0 or fn > 536870911: return None
            if wt == 0:
                v, pos = _read_varint(raw, pos)
                out[fn] = v
            elif wt == 2:
                ln, pos = _read_varint(raw, pos)
                if pos + ln > len(raw): return None
                val = raw[pos:pos+ln]; pos += ln
                n = _try_parse_proto(val)
                if n and len(n) >= 1:
                    out[fn] = n
                else:
                    try:    out[fn] = val.decode('utf-8')
                    except: out[fn] = val.hex()
            elif wt == 5:
                if pos+4 > len(raw): return None
                out[fn] = raw[pos:pos+4].hex(); pos += 4
            elif wt == 1:
                if pos+8 > len(raw): return None
                out[fn] = raw[pos:pos+8].hex(); pos += 8
            else: return None
            seen += 1
        return out if seen else None
    except: return None

def strip_major_login_prefix(body: bytes) -> bytes:
    if len(body) <= 64:
        return body
    try:
        d0 = parse_proto(body)
        if 8 in d0:
            return body
    except Exception:
        pass
    try:
        d64 = parse_proto(body[64:])
        if 8 in d64:
            return body[64:]
    except Exception:
        pass
    return body[64:]

def _find_url_in_proto(d):
    preferred = []
    fallback = []

    def scan(x, depth):
        if depth > 10:
            return
        if isinstance(x, str):
            s = x.strip()
            if 'freefiremobile.com' in s and ' ' not in s and len(s) < 200:
                if s.startswith('http'):
                    preferred.append(s)
                else:
                    preferred.append('https://' + s.strip('/'))
            elif s.startswith('http') and '.' in s and ' ' not in s and len(s) < 200:
                fallback.append(s)
        elif isinstance(x, dict):
            for v in x.values():
                scan(v, depth + 1)
        elif isinstance(x, list):
            for v in x:
                scan(v, depth + 1)

    scan(d, 0)
    if preferred:
        return preferred[0].rstrip('/')
    if fallback:
        return fallback[0].rstrip('/')
    return None

# ============================================================
#  TOKEN GRANT
# ============================================================
def token_grant(session, uid, password, client_ip=None):
    url = "https://100067.connect.garena.com/oauth/guest/token/grant"
    hashed_pw = hash_password(password)
    payload = {
        "uid": str(uid), "password": hashed_pw,
        "response_type": "token", "client_type": "2",
        "client_secret": CLIENT_SECRET, "client_id": "100067"
    }
    headers = {
        "User-Agent": random_user_agent_msdk(),
        "Accept": "application/json",
        "Accept-Encoding": "gzip",
        "Connection": "Keep-Alive"
    }
    if client_ip:
        headers['X-Forwarded-For'] = client_ip
        headers['X-Real-IP'] = client_ip
    resp = session.post(url, data=payload, headers=headers, timeout=15)
    if resp.status_code != 200:
        resp.raise_for_status()
    data = resp.json()
    access_token = data.get('access_token')
    open_id = data.get('open_id')
    if not access_token or not open_id:
        raise Exception(f"Token grant failed: {data}")
    return access_token, open_id

# ============================================================
#  MAJOR REGISTER
# ============================================================
def major_register(session, nick_prefix, access_token, open_id, region, client_ip=None):
    url = "https://loginbp.ggpolarbear.com/MajorRegister"
    exp_digits = {'0':'⁰','1':'¹','2':'²','3':'³','4':'⁴','5':'⁵','6':'⁶','7':'⁷','8':'⁸','9':'⁹'}
    num = random.randint(1,99999)
    suffix = ''.join(exp_digits[d] for d in f"{num:05d}")
    nickname = nick_prefix[:7] + suffix
    lang = REGION_LANG.get(region.upper(), "en")
    xor_key = [0x30,0x30,0x30,0x32,0x30,0x31,0x37,0x30,0x30,0x30,0x30,0x30,0x32,0x30,0x31,0x37,
               0x30,0x30,0x30,0x30,0x30,0x32,0x30,0x31,0x37,0x30,0x30,0x30,0x30,0x30,0x32,0x30]
    encoded = ''.join(chr(ord(c) ^ xor_key[i % len(xor_key)]) for i, c in enumerate(open_id))
    unicode_esc = ''.join(c if 32 <= ord(c) <= 126 else f'\\u{ord(c):04x}' for c in encoded)
    field_bytes = codecs.decode(unicode_esc, 'unicode_escape').encode('latin1')
    fields = {
        "1": nickname, "2": access_token, "3": open_id,
        "5": 102000007, "6": 4, "7": 1, "13": 1,
        "14": field_bytes, "15": lang, "16": 2,
        "20": "2.127.16", "21": 1
    }
    plain = assemble_proto(fields)
    encrypted = aes_encrypt(plain)
    headers = {
        "Accept-Encoding":"gzip", "Authorization":"Bearer", "Connection":"Keep-Alive",
        "Content-Type":"application/x-www-form-urlencoded", "Expect":"100-continue",
        "Host": url.split('/')[2], "ReleaseVersion": OB_VERSION,
        "User-Agent": random_user_agent_unity(), "X-GA":"v1 1",
        "X-Unity-Version":"2022.3.47f1"
    }
    if client_ip:
        headers['X-Forwarded-For'] = client_ip
        headers['X-Real-IP'] = client_ip
    resp = session.post(url, headers=headers, data=encrypted, timeout=15)
    if resp.status_code != 200:
        resp.raise_for_status()
    return parse_proto(resp.content)

# ============================================================
#  MAJOR LOGIN
# ============================================================
def major_login(session, access_token, open_id, region, lang, client_ip=None):
    url = "https://loginbp.ggpolarbear.com/MajorLogin"
    now = str(datetime.now())[:-7]
    user_id = generate_random_user_id()

    fields = {
        3: now, 4: "free fire", 5: 2, 7: CLIENT_VERSION,
        8: "Android OS 11 / API-30 (RQ3A.210805.001)",
        9: "Handheld", 10: "Verizon", 11: "WIFI", 12: 1080, 13: 2400,
        14: "440", 15: "ARMv8", 16: 6144,
        17: "Adreno (TM) 650", 18: "OpenGL ES 3.2 V@1.50",
        19: user_id, 20: "", 21: "en", 22: open_id, 23: "4", 24: "Handheld",
        25: {6: 55, 8: 81}, 29: access_token, 30: 2,
        41: "Verizon", 42: "WIFI",
        57: "7428b253defc164018c604a1ebbfebdf",
        60: 128512, 61: 38000, 62: 110731, 63: 18000, 64: 18000,
        65: 26628, 66: 25000, 67: 119234, 73: 3,
        74: "/data/app/~~random/base.apk", 76: 1, 77: "hash|base.apk",
        78: 3, 79: 2, 81: "64", 83: "2024010012", 86: "OpenGLES3", 87: 16383,
        88: 4, 89: b"FwQVTgUPX1UaUllDDwcWCRBpWAUOUgsvA1snWlBaO1kFYg==",
        92: 9000, 93: "android", 94: "", 95: 110009, 97: 1, 98: 0, 99: "4", 100: "4",
    }
    plain = assemble_proto(fields)
    encrypted = aes_encrypt(plain)
    headers = {
        "User-Agent": random_user_agent_unity(),
        "Accept": "*/*", "Accept-Encoding": "deflate, gzip",
        "X-Ga-Sv": "1789534056", "Authorization": "Bearer ",
        "X-Ga": "v1 1", "ReleaseVersion": OB_VERSION,
        "Content-Type": "application/x-www-form-urlencoded",
        "X-Unity-Version": "2022.3.47f1",
    }
    if client_ip:
        headers['X-Forwarded-For'] = client_ip
        headers['X-Real-IP'] = client_ip
    resp = session.post(url, headers=headers, data=encrypted, timeout=15)
    if resp.status_code != 200:
        resp.raise_for_status()
    body = strip_major_login_prefix(resp.content)
    decoded = parse_proto(body)
    jwt = decoded.get(8)
    if isinstance(jwt, list):
        jwt = jwt[0]
    return decoded, jwt

# ============================================================
#  GET LOGIN DATA
# ============================================================
def build_get_login_data_payload(jwt_token, access_token, client_ip=None):
    try:
        parts = jwt_token.split('.')
        if len(parts) < 2:
            return None
        payload_b64 = parts[1] + '=' * ((4 - len(parts[1]) % 4) % 4)
        decoded = json.loads(base64.urlsafe_b64decode(payload_b64).decode('utf-8'))
        external_id   = decoded.get('external_id') or decoded.get('external_uid')
        signature_md5 = decoded.get('signature_md5') or "7428b253defc164018c604a1ebbfebdf"
        if not external_id:
            return None

        now = str(datetime.now())[:-7]
        user_id = generate_random_user_id()

        fields = {
            3: now, 4: "free fire", 5: 2, 7: CLIENT_VERSION,
            8: "Android OS 11 / API-30 (RQ3A.210805.001)",
            9: "Handheld", 10: "Verizon", 11: "WIFI", 12: 1080, 13: 2400,
            14: "440", 15: "ARMv8", 16: 6144,
            17: "Adreno (TM) 650", 18: "OpenGL ES 3.2 V@1.50",
            19: user_id, 20: "", 21: "en",
            22: external_id, 23: "4", 24: "Handheld",
            25: {6: 55, 8: 81}, 29: access_token, 30: 2,
            41: "Verizon", 42: "WIFI",
            57: signature_md5,
            60: 128512, 61: 38000, 62: 110731, 63: 18000, 64: 18000,
            65: 26628, 66: 25000, 67: 119234, 73: 3,
            74: "/data/app/~~random/base.apk", 76: 1, 77: "hash|base.apk",
            78: 3, 79: 2, 81: "64", 83: "2024010012", 86: "OpenGLES3", 87: 16383,
            88: 4, 89: b"FwQVTgUPX1UaUllDDwcWCRBpWAUOUgsvA1snWlBaO1kFYg==",
            92: 9000, 93: "android", 94: "", 95: 110009, 97: 1, 98: 0, 99: "4", 100: "4",
        }
        plain = assemble_proto(fields)
        return aes_encrypt(plain)
    except Exception:
        return None

def get_login_data_safe(jwt_token, access_token, base_url, client_ip=None):
    if not base_url:
        return False
    if base_url.endswith('/'):
        base_url = base_url[:-1]
    url = f"{base_url}/GetLoginData"

    payload = build_get_login_data_payload(jwt_token, access_token, client_ip)
    if not payload:
        return False

    headers = {
        'Authorization': f'Bearer {jwt_token}',
        'X-Unity-Version': '2018.4.11f1',
        'X-GA': 'v1 1',
        'ReleaseVersion': OB_VERSION,
        'Content-Type': 'application/x-www-form-urlencoded',
        'User-Agent': 'Dalvik/2.1.0 (Linux; U; Android 9; G011A Build/PI)',
        'Connection': 'close',
        'Accept-Encoding': 'gzip, deflate, br',
    }
    if client_ip:
        headers['X-Forwarded-For'] = client_ip
        headers['X-Real-IP'] = client_ip
    try:
        response = requests.post(url, headers=headers, data=payload, verify=False, timeout=10)
        return response.status_code == 200
    except Exception:
        return False

# ============================================================
#  ACTIVATE  (fresh login + getlogindata)
# ============================================================
def activate_account(uid, password, region="IND", client_ip=None):
    hashed_pw = hash_password(password)
    guest_headers = {
        "Host": "100067.connect.garena.com",
        "User-Agent": random_user_agent_msdk(),
        "Content-Type": "application/x-www-form-urlencoded",
        "Accept-Encoding": "gzip, deflate",
        "Connection": "close"
    }
    if client_ip:
        guest_headers['X-Forwarded-For'] = client_ip
        guest_headers['X-Real-IP'] = client_ip
    guest_data = {
        "uid": uid, "password": hashed_pw,
        "response_type": "token", "client_type": "2",
        "client_secret": CLIENT_SECRET, "client_id": "100067"
    }
    try:
        resp = requests.post(
            "https://100067.connect.garena.com/oauth/guest/token/grant",
            headers=guest_headers, data=guest_data, verify=False, timeout=10
        )
        if resp.status_code != 200:
            return False
        gjson = resp.json()
        access_token = gjson.get('access_token')
        open_id      = gjson.get('open_id')
        if not access_token or not open_id:
            return False
    except Exception:
        return False

    session = requests.Session()
    session.verify = False
    try:
        login_resp, jwt = major_login(session, access_token, open_id, region, "en", client_ip)
    except Exception:
        return False

    if not jwt:
        return False

    base_url = _find_url_in_proto(login_resp) or REGION_BASE_URLS.get(region.upper(), "https://client.ind.freefiremobile.com")
    return get_login_data_safe(jwt, access_token, base_url, client_ip=client_ip)

# ============================================================
#  DECODE NICKNAME
# ============================================================
def decode_nickname(jwt):
    try:
        parts = jwt.split('.')
        payload = parts[1] + '=' * (4 - len(parts[1]) % 4)
        data = json.loads(base64.b64decode(payload))
        lock_region = data.get("lock_region") or data.get("noti_region")
        raw = data.get("nickname")
        if raw:
            decoded = base64.b64decode(raw)
            nick = bytes([decoded[i] ^ NICK_XOR_KEY[i % len(NICK_XOR_KEY)] for i in range(len(decoded))])
            nick = nick.decode('utf-8', errors='ignore')
        else:
            nick = ""
        return lock_region, nick
    except:
        return None, None

# ============================================================
#  SPIN
# ============================================================
def send_spin(jwt):
    body = binascii.unhexlify(SPIN_BODY_HEX)
    headers = {
        "User-Agent":       "UnityPlayer/2018.4.12f1 (UnityWebRequest/1.0, libcurl/8.5.0-DEV)",
        "Accept":           "*/*",
        "Accept-Encoding":  "deflate, gzip",
        "X-GA-SV":          str(int(time.time())),
        "Authorization":    f"Bearer {jwt}",
        "X-GA":             "v1 1",
        "ReleaseVersion":   "OB55",
        "Content-Type":     "application/x-www-form-urlencoded",
        "X-Unity-Version":  "2018.4.12f1",
    }
    r = requests.post(SPIN_URL, data=body, headers=headers, timeout=20, verify=False)
    return r.status_code, r.content

# ============================================================
#  RESPONSE PARSER
# ============================================================
def parse_gacha_response(data: bytes) -> dict:
    if data and data[:2] == b'\x1f\x8b':
        try: data = zlib.decompress(data, 16 + zlib.MAX_WBITS)
        except: pass

    parsed = _try_parse_proto(data) or {}
    items = []

    inner = parsed.get(1)
    if isinstance(inner, dict):
        raw = inner.get(2, "")
        if isinstance(raw, str):
            m = re.match(r'\s*(\d+)\s*[→\-–>]+\s*(.+?)\s*$', raw)
            if m:
                iid = int(m.group(1))
                iname = m.group(2).strip()
                items.append({"id": iid, "name": iname})

    if not items:
        for mm in re.finditer(r'\b(\d{9})\b', str(parsed)):
            iid = int(mm.group(1))
            if not any(it['id'] == iid for it in items):
                items.append({"id": iid, "name": None})

    for it in items:
        default_name, rarity = classify_item(it['id'])
        if not it['name'] or it['name'].startswith("UNKNOWN"):
            it['name'] = default_name
        it['rarity'] = rarity

    return {"items": items, "raw": parsed}

# ============================================================
#  CREATE SESSION
# ============================================================
def create_session():
    s = requests.Session()
    s.verify = False
    adapter = requests.adapters.HTTPAdapter(pool_connections=100, pool_maxsize=100)
    s.mount('https://', adapter)
    return s

# ============================================================
#  GENERATOR CLASS  (batch mode: register → activate → spin)
# ============================================================
class ArafatGenerator:
    def __init__(self, region, prefix, pass_base, total, threads, retries,
                 save_folder, save_name, special_file):
        self.region = region.upper()
        self.prefix = prefix
        self.pass_base = pass_base
        self.total = total
        self.threads = threads
        self.retries = retries
        self.save_folder = save_folder
        self.save_name = save_name
        self.save_path = os.path.join(save_folder, save_name)
        self.special_file = special_file

        # Non-activated accounts are kept separately instead of being discarded.
        self.non_active_folder = os.path.join(save_folder, "Non-active-Acc")
        self.non_active_path = os.path.join(self.non_active_folder, "non_active_accounts.json")
        self.generated_folder = os.path.join(save_folder, "Generated-Acc")

        self.saved_count = 0
        self.non_active_count = 0
        self.skipped_count = 0
        self.rare_count = 0
        self.very_rare_count = 0
        self.results = []
        self.lock = threading.Lock()
        self.start_time = None
        self.print_lock = threading.Lock()

        os.makedirs(self.save_folder, exist_ok=True)
        os.makedirs(self.non_active_folder, exist_ok=True)
        os.makedirs(self.generated_folder, exist_ok=True)

        # ensure files exist
        if not os.path.exists(self.save_path):
            with open(self.save_path, "w", encoding="utf-8") as f:
                json.dump([], f)
        if not os.path.exists(self.special_file):
            with open(self.special_file, "w", encoding="utf-8") as f:
                json.dump([], f)

        if not os.path.exists(self.non_active_path):
            with open(self.non_active_path, "w", encoding="utf-8") as f:
                json.dump([], f)

    def _safe_print(self, msg, color=WHITE, bold=False):
        with self.print_lock:
            if bold:
                msg = f"{BOLD}{color}{msg}{RESET}"
            else:
                msg = f"{color}{msg}{RESET}"
            print(msg)

    # ---------------------------------------------------------
    #  PHASE 1: register one account
    # ---------------------------------------------------------
    def _register_one(self, thread_id, idx):
        session = create_session()
        plain_pass = random_password(self.pass_base)
        nickname = random_nickname(self.prefix)
        region = self.region
        client_ip = IPRotator.get_random_ip(self.region)

        for attempt in range(1, self.retries + 1):
            try:
                uid = register_guest(session, plain_pass, client_ip)
                if not uid:
                    continue
                access_token, open_id = token_grant(session, uid, plain_pass, client_ip)
                if not access_token:
                    continue
                reg_resp = major_register(session, nickname[:7], access_token, open_id, region, client_ip)
                if not reg_resp:
                    continue
                game_uid = str(reg_resp.get(3))
                if not game_uid or game_uid == "None":
                    continue
                login_resp, jwt = major_login(session, access_token, open_id, region, "en", client_ip)
                if not jwt:
                    continue
                _, nickname_dec = decode_nickname(jwt)
                if not nickname_dec:
                    nickname_dec = nickname

                self._safe_print(
                    f"   📝 [{idx}] Registered UID={uid} | Game={game_uid} | {nickname_dec}",
                    GREEN
                )

                return {
                    "uid": uid,
                    "game_uid": game_uid,
                    "password": plain_pass,
                    "nickname": nickname_dec,
                    "region": region,
                    "jwt": jwt,
                    "client_ip": client_ip,
                    "thread": thread_id
                }
            except Exception as e:
                if attempt < self.retries:
                    time.sleep(0.1 * (attempt + 1))
                    continue
                self._safe_print(f"   ❌ [{idx}] Register failed: {e}", RED)
                return None
        return None

    # ---------------------------------------------------------
    #  PHASE 2: activate one account
    # ---------------------------------------------------------
    def _activate_one(self, acc, idx):
        try:
            uid = acc["uid"]
            pwd = acc["password"]
            region = acc["region"]
            client_ip = acc.get("client_ip")
            activated = activate_account(uid, pwd, region=region, client_ip=client_ip)
            if activated:
                self._safe_print(f"   ✅ [{idx}] ACTIVATED UID={uid}", GREEN)
            else:
                self._safe_print(f"   ❌ [{idx}] Activation failed UID={uid}", RED)
            return activated
        except Exception as e:
            self._safe_print(f"   ❌ [{idx}] Activation error: {e}", RED)
            return False

    # ---------------------------------------------------------
    #  PHASE 3: spin one account (inbuilt JWT via uid+password)
    # ---------------------------------------------------------
    def _spin_one(self, acc, idx):
        uid = acc["uid"]
        pwd = acc["password"]
        client_ip = acc.get("client_ip")
        try:
            # Fresh JWT for spin
            session = create_session()
            access_token, open_id = token_grant(session, uid, pwd, client_ip)
            _, jwt = major_login(session, access_token, open_id, acc["region"], "en", client_ip)
            if not jwt:
                self._safe_print(f"   ❌ [{idx}] Spin JWT failed UID={uid}", RED)
                return []
        except Exception as e:
            self._safe_print(f"   ❌ [{idx}] Spin JWT error: {e}", RED)
            return []

        try:
            status, resp = send_spin(jwt)
        except Exception as e:
            self._safe_print(f"   ❌ [{idx}] Spin request failed: {e}", RED)
            return []

        if status != 200:
            err = resp.decode("utf-8", errors="ignore")[:100]
            self._safe_print(f"   ❌ [{idx}] Spin HTTP {status}: {err}", RED)
            return []

        try:
            parsed = parse_gacha_response(resp)
            items = parsed.get("items", [])
        except Exception as e:
            self._safe_print(f"   ❌ [{idx}] Parse error: {e}", RED)
            return []

        if not items:
            self._safe_print(f"   ⚠️ [{idx}] No item IDs for UID={uid}", YELLOW)
            return []

        collected = []
        for it in items:
            iid    = it["id"]
            iname  = it["name"]
            rarity = it["rarity"]
            collected.append(it)

            if rarity == "VERY_RARE":
                self._append_special(uid, pwd, iid, iname, rarity)
                with self.lock:
                    self.very_rare_count += 1
                self._safe_print(f"   ★★★ [{idx}] VERY RARE: {iname} ({iid}) UID={uid}", PURPLE, bold=True)
            elif rarity == "RARE":
                self._append_special(uid, pwd, iid, iname, rarity)
                with self.lock:
                    self.rare_count += 1
                self._safe_print(f"   ⭐ [{idx}] RARE: {iname} ({iid}) UID={uid}", YELLOW, bold=True)
            else:
                self._safe_print(f"   📦 [{idx}] NORMAL: {iname} ({iid}) UID={uid}", CYAN)

        return collected

    # ---------------------------------------------------------
    #  APPEND special (RARE + VERY_RARE) to json file
    # ---------------------------------------------------------
    def _append_special(self, uid, password, item_id, item_name, rarity):
        entry = {
            "uid": uid,
            "password": password,
            "item_id": item_id,
            "item_name": item_name,
            "rarity": rarity,
            "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        }
        with self.lock:
            try:
                with open(self.special_file, "r", encoding="utf-8") as f:
                    data = json.load(f)
            except Exception:
                data = []
            data.append(entry)
            with open(self.special_file, "w", encoding="utf-8") as f:
                json.dump(data, f, indent=2, ensure_ascii=False)

    # ---------------------------------------------------------
    #  SAVE FULL GENERATED BATCH BEFORE ACTIVATION
    # ---------------------------------------------------------
    def _save_generated_batch(self, registered, batch_num):
        """Persist every generated account before any activation starts."""
        safe_accounts = []
        for acc in registered:
            safe_accounts.append({
                "uid": acc.get("uid"),
                "game_uid": acc.get("game_uid"),
                "password": acc.get("password"),
                "nickname": acc.get("nickname"),
                "region": acc.get("region"),
                "activated": False,
                "thread": acc.get("thread"),
                "generated_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            })
        path = os.path.join(self.generated_folder, f"batch_{batch_num:03d}.json")
        with open(path, "w", encoding="utf-8") as f:
            json.dump(safe_accounts, f, indent=2, ensure_ascii=False)
        self._safe_print(f"   {GREEN}✓ All {len(safe_accounts)} generated accounts saved → {path}{RESET}")
        return path

    # ---------------------------------------------------------
    #  SAVE NON-ACTIVE ACCOUNT
    # ---------------------------------------------------------
    def _save_non_active(self, acc, reason="Activation failed"):
        entry = {
            "uid": acc.get("uid"),
            "game_uid": acc.get("game_uid"),
            "password": acc.get("password"),
            "nickname": acc.get("nickname"),
            "region": acc.get("region"),
            "activated": False,
            "reason": reason,
            "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "thread": acc.get("thread")
        }
        with self.lock:
            try:
                with open(self.non_active_path, "r", encoding="utf-8") as f:
                    data = json.load(f)
            except Exception:
                data = []
            data.append(entry)
            with open(self.non_active_path, "w", encoding="utf-8") as f:
                json.dump(data, f, indent=2, ensure_ascii=False)
            self.non_active_count += 1

        self._safe_print(
            f"   ◌ NON-ACTIVE [{acc.get('uid')}] → {self.non_active_path}",
            YELLOW
        )

    def _activate_batch_sequential(self, registered):
        """Activate a completed registration batch sequentially, one account at a time."""
        activated_list = []
        for idx, acc in enumerate(registered, 1):
            self._safe_print(
                f"\\n{CYAN}  [ACTIVATE {idx}/{len(registered)}] UID={acc.get('uid')} — starting...{RESET}"
            )
            try:
                activated = self.activate_account(acc)
            except Exception as exc:
                activated = None
                self._safe_print(f"{RED}  ✗ Activation error: {exc}{RESET}")
            if activated:
                activated_list.append(activated)
                self._safe_print(f"{GREEN}  ✓ Activated UID={acc.get('uid')}{RESET}")
            else:
                self._save_non_active(acc, "Activation failed or inactive")
                self._safe_print(f"{YELLOW}  ◌ Non-active UID={acc.get('uid')}{RESET}")
        return activated_list

    # ---------------------------------------------------------
    #  SKIP GUEST GENERATION → SPIN SAVED GENERATED ACCOUNTS
    # ---------------------------------------------------------
    def _load_generated_accounts(self):
        """Load previously generated accounts from Generated-Acc/batch_*.json."""
        accounts = []
        if not os.path.isdir(self.generated_folder):
            return accounts

        files = sorted(
            [f for f in os.listdir(self.generated_folder)
             if f.lower().endswith(".json") and f.lower().startswith("batch_")]
        )
        for filename in files:
            path = os.path.join(self.generated_folder, filename)
            try:
                with open(path, "r", encoding="utf-8") as f:
                    data = json.load(f)
                if not isinstance(data, list):
                    continue
                for acc in data:
                    if not isinstance(acc, dict):
                        continue
                    if not acc.get("uid") or not acc.get("password"):
                        continue
                    item = dict(acc)
                    item.setdefault("region", self.region)
                    accounts.append(item)
            except Exception as exc:
                self._safe_print(f"   ⚠ Could not read {path}: {exc}", YELLOW)

        # Prevent duplicate UID spins if the same account exists in multiple batch files.
        unique = []
        seen = set()
        for acc in accounts:
            uid = str(acc.get("uid"))
            if uid in seen:
                continue
            seen.add(uid)
            unique.append(acc)
        return unique

    def run_saved_spin(self):
        """Skip guest generation/activation and spin all saved Generated-Acc accounts."""
        print_banner()
        ui_header("SAVED ACCOUNT SPIN", "Guest generation skipped → Generated-Acc → Spin")
        ui_status("Generated Folder", self.generated_folder, CYAN)
        ui_status("Spin Output", self.special_file, PURPLE)
        print()

        accounts = self._load_generated_accounts()
        if not accounts:
            self._safe_print(
                f"{RED}✗ No usable accounts found in {self.generated_folder}{RESET}", RED, bold=True
            )
            return

        self.start_time = time.time()
        self._safe_print(
            f"{GREEN}✓ Loaded {len(accounts)} saved account(s). Guest generation and activation are skipped.{RESET}",
            GREEN
        )
        self._safe_print(
            f"{CYAN}▶ Spinning saved accounts...{RESET}", CYAN
        )

        with ThreadPoolExecutor(max_workers=min(self.threads, len(accounts))) as ex:
            futures = {
                ex.submit(self._spin_one, acc, i + 1): acc
                for i, acc in enumerate(accounts)
            }
            for fut in as_completed(futures):
                try:
                    fut.result()
                except Exception as exc:
                    acc = futures[fut]
                    self._safe_print(
                        f"{RED}✗ Spin error UID={acc.get('uid')}: {exc}{RESET}", RED
                    )

        elapsed = time.time() - self.start_time
        self._safe_print(
            f"{BOLD}{GREEN}✓ Saved-account spin complete: {len(accounts)} account(s) processed in {elapsed:.1f}s{RESET}",
            GREEN, bold=True
        )

    # ---------------------------------------------------------
    #  BATCH LOOP
    # ---------------------------------------------------------
    def run(self):
        print_banner()
        ui_header("ACCOUNT GENERATOR", "Batch register → activate → spin")
        ui_status("Region", self.region, GREEN)
        ui_status("Batch / Threads", self.threads, CYAN)
        ui_status("Target Active", self.total, GREEN)
        ui_status("Active Output", self.save_path, GREEN)
        ui_status("Generated Output", self.generated_folder, CYAN)
        ui_status("Non-Active Output", self.non_active_path, YELLOW)
        ui_status("Rare Output", self.special_file, PURPLE)
        print()

        self.start_time = time.time()
        batch_num = 0

        while self.saved_count < self.total:
            batch_num += 1
            remaining = self.total - self.saved_count
            batch_size = min(self.threads, remaining)

            self._safe_print(
                f"\n{BOLD}{PURPLE}══════ BATCH #{batch_num} ({batch_size} accounts) ══════{RESET}",
                PURPLE, bold=True
            )

            # ---- PHASE 1: Register batch ----
            self._safe_print(f"{CYAN}  ▶ Phase 1/3: Registering {batch_size} accounts (parallel)...{RESET}")
            registered = []
            with ThreadPoolExecutor(max_workers=batch_size) as ex:
                futures = {}
                for i in range(batch_size):
                    futures[ex.submit(self._register_one, i, i + 1)] = i
                for fut in as_completed(futures):
                    r = fut.result()
                    if r:
                        registered.append(r)

            self._safe_print(f"{CYAN}  ✔ Registered {len(registered)}/{batch_size}{RESET}")

            if not registered:
                self._safe_print(f"{RED}  ✗ No accounts registered in this batch, retrying...{RESET}")
                time.sleep(0.5)
                continue

            # ---- SAVE GENERATED ACCOUNTS BEFORE ACTIVATION ----
            self._save_generated_batch(registered, batch_num)

            # ---- PHASE 2: Activate sequentially, one account at a time ----
            self._safe_print(f"{CYAN}  ▶ Phase 2/3: Activating {len(registered)} accounts (one-by-one)...{RESET}")
            activated_list = []
            for i, acc in enumerate(registered, 1):
                ok = self._activate_one(acc, i)
                if ok:
                    activated_list.append(acc)

            self._safe_print(f"{CYAN}  ✔ Activated {len(activated_list)}/{len(registered)}{RESET}")

            # ---- Save only activated ----
            for acc in activated_list:
                save_acc = {
                    "uid": acc["uid"],
                    "game_uid": acc["game_uid"],
                    "password": acc["password"],
                    "nickname": acc["nickname"],
                    "region": acc["region"],
                    "activated": True,
                    "thread": acc["thread"]
                }
                self._save_account(save_acc)
                with self.lock:
                    self.saved_count += 1
                    self.results.append(save_acc)
                self._print_success(self.saved_count, self.total, save_acc)

            skipped = len(registered) - len(activated_list)
            self.skipped_count += skipped

            # Keep every registered account that did not activate.
            activated_ids = {a.get("uid") for a in activated_list}
            for acc in registered:
                if acc.get("uid") not in activated_ids:
                    self._save_non_active(acc, "Activation failed or inactive")

            if skipped:
                self._safe_print(
                    f"{YELLOW}  ◌ Non-active: {skipped} → {self.non_active_path}{RESET}"
                )

            # ---- PHASE 3: Spin all activated ----
            if activated_list:
                self._safe_print(f"{CYAN}  ▶ Phase 3/3: Spinning {len(activated_list)} accounts (parallel)...{RESET}")
                with ThreadPoolExecutor(max_workers=len(activated_list)) as ex:
                    futures = {}
                    for i, acc in enumerate(activated_list):
                        futures[ex.submit(self._spin_one, acc, i + 1)] = acc
                    for fut in as_completed(futures):
                        try:
                            fut.result()
                        except Exception:
                            pass

            self._safe_print(
                f"{BOLD}{GREEN}  Batch #{batch_num} done → Saved {len(activated_list)}, "
                f"Skipped {skipped}, VR={self.very_rare_count}, R={self.rare_count}{RESET}"
            )

        # ---- Final summary ----
        elapsed = time.time() - self.start_time
        rate = self.saved_count / elapsed if elapsed > 0 else 0
        print(f"""
{BOLD}{GREEN}╔══════════════════════════════════════════════════════╗
║                 DONE!  (.)                        ║
╠══════════════════════════════════════════════════════╣
║  ✅ Activated & Saved: {self.saved_count:<32} ║
║  ◌ Non-Active Saved: {self.non_active_count:<32} ║
║  ★★★ VERY RARE items: {self.very_rare_count:<32} ║
║  ⭐ RARE items:       {self.rare_count:<32} ║
║  ⏱️  Time: {elapsed:.1f}s{' ' * (41 - len(f'{elapsed:.1f}s'))}║
║  ⚡ Speed: {rate:.2f}/s{' ' * (41 - len(f'{rate:.2f}/s'))}║
║  💾 Active   → {self.save_path:<39} ║
║  ◌ Inactive → {self.non_active_path:<39} ║
║  💎 Special  → {self.special_file:<39} ║
╚══════════════════════════════════════════════════════╝{RESET}
""")

    def _print_success(self, current, total, acc):
        elapsed = time.time() - self.start_time if self.start_time else 0
        speed = current / elapsed if elapsed > 0 else 0
        eta = (total - current) / speed if speed > 0 else 0
        filled = int(30 * current / total)
        bar = '█' * filled + '░' * (30 - filled)
        print(f"""
{BOLD}{GREEN}╔══════════════════════════════════════════════════════╗{RESET}
{BOLD}{GREEN}║     ✅ ACTIVATED ACCOUNT #{current}/{total} SAVED!            ║{RESET}
{BOLD}{GREEN}╚══════════════════════════════════════════════════════╝{RESET}
{BOLD}{CYAN}  UID:{RESET} {acc['uid']}
{BOLD}{CYAN}  GAME UID:{RESET} {acc['game_uid']}
{BOLD}{CYAN}  PASSWORD:{RESET} {acc['password']}
{BOLD}{CYAN}  NAME:{RESET} {acc['nickname']}
{BOLD}{CYAN}  REGION:{RESET} {acc['region']}
{BOLD}{CYAN}  ACTIVATED:{RESET} ✅
{BOLD}{CYAN}  THREAD:{RESET} {acc['thread']}
{BOLD}{YELLOW}  [{bar}] {current}/{total} | {speed:.2f}/s | ETA: {eta:.0f}s{RESET}
""")

    def _save_account(self, acc):
        with self.lock:
            try:
                with open(self.save_path, "r", encoding="utf-8") as f:
                    data = json.load(f)
            except Exception:
                data = []
            data.append(acc)
            with open(self.save_path, "w", encoding="utf-8") as f:
                json.dump(data, f, indent=2, ensure_ascii=False)

# ============================================================
#  MAIN
# ============================================================
def main():
    try:
        print_banner()
        ui_header("SETUP", "Configure the generator before starting")
        print(f"\n{BOLD}{CYAN}🌍 Available Regions{RESET}")
        for key, val in SUPPORTED_REGIONS.items():
            print(f"  {key}. {val}")
        region_choice = input(f"\n{BOLD}Region (default 1=IND): {RESET}").strip() or "1"
        region = SUPPORTED_REGIONS.get(region_choice, "IND")

        name_prefix = input(f"{BOLD}Name prefix (default GUEST): {RESET}").strip() or "GUEST"
        pass_base = input(f"{BOLD}Password base (default GUESTT): {RESET}").strip() or "GUESTT"

        try:
            total = int(input(f"{BOLD}How many accounts? (default 10): {RESET}").strip() or "10")
        except:
            total = 10
        try:
            threads = int(input(f"{BOLD}Threads = Batch size (1-50, default 5): {RESET}").strip() or "5")
            threads = max(1, min(threads, 50))
        except:
            threads = 5
        try:
            retries = int(input(f"{BOLD}Retries (default 3): {RESET}").strip() or "3")
            retries = max(1, min(retries, 10))
        except:
            retries = 3

        print(f"\n{BOLD}{PURPLE}MODE{RESET}")
        print(f"  {CYAN}1.{RESET} Generate Guest → Activate → Spin")
        print(f"  {CYAN}2.{RESET} Skip Guest Generation → Spin accounts from Generated-Acc")
        mode = input(f"{BOLD}Select mode (default 1): {RESET}").strip() or "1"
        mode = "2" if mode == "2" else "1"

        save_folder = input(f"{BOLD}Save folder (default 'accounts'): {RESET}").strip() or "accounts"
        save_name = input(f"{BOLD}File name (default 'accounts.json'): {RESET}").strip() or "accounts.json"
        if not save_name.lower().endswith(".json"):
            save_name += ".json"

        special_name = input(f"{BOLD}Special/rare items file (default 'special_id.json'): {RESET}").strip() or "special_id.json"
        if not special_name.lower().endswith(".json"):
            special_name += ".json"
        special_file = os.path.join(save_folder, special_name)

        ui_header("READY", "Output folders are prepared")
        print(f"{GREEN}  ✓ Active accounts  → {os.path.join(save_folder, save_name)}{RESET}")
        print(f"{YELLOW}  ✓ Non-active      → {os.path.join(save_folder, 'Non-active-Acc', 'non_active_accounts.json')}{RESET}")
        print(f"{PURPLE}  ✓ Rare / VR items → {special_file}{RESET}")
        if mode == "2":
            print(f"{CYAN}  ✓ Flow             → Load Generated-Acc → Spin{RESET}")
        else:
            print(f"{CYAN}  ✓ Flow             → Register → Activate → Spin → Repeat{RESET}")

        input(f"\n{BOLD}{GREEN}Press ENTER to start...{RESET}")

        gen = ArafatGenerator(
            region, name_prefix, pass_base, total, threads, retries,
            save_folder, save_name, special_file
        )
        if mode == "2":
            gen.run_saved_spin()
        else:
            gen.run()
    except Exception as e:
        print(f"{RED}❌ Error: {e}{RESET}")
        import traceback
        traceback.print_exc()
        input("Enter to exit...")

if __name__ == "__main__":
    main()